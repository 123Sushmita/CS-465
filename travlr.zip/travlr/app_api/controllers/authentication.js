const mongoose = require('mongoose');
const User = require('../models/user');
const passport = require('passport');

const register = async (req, res) => {
    if (!req.body.name || !req.body.email || !req.body.password) {
        return res.status(400).json({ message: 'All fields required.' });
    }

    const user = new User({
        email: req.body.email,
        name: req.body.name,
        password: ''
    });
    user.setPassword(req.body.password);
    
    try {
        const newUser = await user.save();
        const token = newUser.generateJWT();
        res.status(201).json({ token });
    } catch (err) {
        res.status(400).json({ message: 'Error registering user.', error: err.message });
    }
}


const login = (req, res, next) => { 
    // Validate message to ensure that email and password are present. 
    if (!req.body.email || !req.body.password) { 
      return res 
        .status(400) 
        .json({"message": "All fields required"}); 
    } 
 
    // Delegate authentication  to passport module 
    passport.authenticate('local', (err, user, info) => { 
      if (err) { 
        // Error in Authentication Process 
        return res.status(500).json({ message: 'Authentication error', error: err });
      } 
       
      if (user) { // Auth succeeded - generate JWT and return to caller 
        const token = user.generateJWT(); 
        res 
          .status(200) 
          .json({token}); 
      } else { // Auth failed return error 
        return res.status(401).json(info || { message: 'Authentication failed' });
      } 
    })(req, res, next); 
};

module.exports = {
    register,
    login
}
