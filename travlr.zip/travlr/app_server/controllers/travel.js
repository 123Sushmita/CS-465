const tripsEndpoint = "http://localhost:3000/api/trips";
const options = {
  method: "GET",
  headers: {
    Accept: "application/json",
  },
};

const travel = async function (req, res, next) {
  console.log("TRAVEL CONTROLLER BEGIN");


  await fetch(tripsEndpoint, options)
    .then((res) => res.json())
    .then((json) => {
      let message = null;

      // If json is not an array
      if (!Array.isArray(json)) {
        message = "API lookup error";
        json = []; // Ensure we don't crash rendering
      } else if (!json.length) {
        // If json is an empty array
        message = "No trips exist in our database!";
      }

      res.render("travel", {
        title: "Travlr Getaways",
        trips: json,
        message,
      });
    })
    .catch((err) => {
      console.error("TRAVEL CONTROLLER ERROR:", err);
      res.status(500).send("Error retrieving trip data");
    });
};

module.exports = {
  travel,
};
