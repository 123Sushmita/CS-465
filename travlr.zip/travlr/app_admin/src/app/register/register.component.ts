import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models/user';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {
  public formError: string = '';
  public formSuccess: string = '';
  public isSubmitting: boolean = false;
  submitted = false;

  credentials = {
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  }

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) { }

  ngOnInit(): void {
  }

  public onRegisterSubmit(): void {
    this.formError = '';
    this.formSuccess = '';
    this.isSubmitting = true;
    
    if (!this.credentials.email || !this.credentials.password || 
          !this.credentials.name) {
      this.formError = 'All fields are required, please try again';
      this.isSubmitting = false;
      return;
    }
    
    if (this.credentials.password !== this.credentials.confirmPassword) {
      this.formError = 'Passwords do not match';
      this.isSubmitting = false;
      return;
    }
    
    this.doRegister();
  }

  private doRegister(): void {
    let newUser = {
      name: this.credentials.name,
      email: this.credentials.email
    } as User;

    // Register user
    this.authenticationService.register(newUser, this.credentials.password);

    // Check if user is logged in (registered successfully)
    if(this.authenticationService.isLoggedIn()) {
      this.formSuccess = 'Registration successful!';
      this.router.navigate(['']);
    } else {
      var timer = setTimeout(() => {
        this.isSubmitting = false;
        if(this.authenticationService.isLoggedIn()) {
          this.formSuccess = 'Registration successful!';
          this.router.navigate(['']);
        } else {
          this.formError = 'Registration failed. Please try again.';
        }
      }, 3000);
    }
  }
}
