import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripCardComponent } from '../trip-card/trip-card.component';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthenticationService } from '../services/authentication.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCardComponent],
  standalone: true,
  templateUrl: './trip-listing.component.html',
  styleUrl: './trip-listing.component.css',
  providers: [TripDataService, HttpClient],
})
export class TripListingComponent implements OnInit, OnDestroy {
  trips: Array<Trip> = [];
  message: string = '';
  private tripSubscription: Subscription | null = null;
  isLoading: boolean = false;

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    console.log('TripListingComponent constructor');
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  public getStuff(): void {
    // Cancel any existing subscription
    if (this.tripSubscription) {
      this.tripSubscription.unsubscribe();
      this.tripSubscription = null;
    }

    this.isLoading = true;
    
    this.tripSubscription = this.tripDataService.getTrips().subscribe({
      next: (value: Trip[]) => {
        this.trips = value;
        this.isLoading = false;
        
        if (value.length > 0) {
          this.message = 'There are ' + value.length + ' trips available.';
        } else {
          this.message = 'There were no trips retrieved from the database';
        }
        console.log(this.message);
      },
      error: (error: any) => {
        this.isLoading = false;
        console.log('Error loading trips: ' + error);
        this.message = 'Error loading trips. Please try again.';
      }
    });
  }

  public addTrip(): void {
    this.router.navigate(['/add-trip']);
  }

  ngOnInit(): void {
    this.getStuff();
  }

  ngOnDestroy(): void {
    // Clean up subscription when component is destroyed
    if (this.tripSubscription) {
      this.tripSubscription.unsubscribe();
    }
  }
}
