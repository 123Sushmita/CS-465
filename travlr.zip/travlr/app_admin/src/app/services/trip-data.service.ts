import { Inject, Injectable } from '@angular/core';
import { Trip } from '../models/trip';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';

@Injectable({
  providedIn: 'root',
})
export class TripDataService {
  baseUrl = 'http://localhost:3000/api';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  public getTrips(): Observable<Trip[]> {
    let url = 'http://localhost:3000/api/trips';
    return this.http.get<Trip[]>(url);
  }

  public getTrip(tripCode: string): Observable<Trip> {
    let url = `http://localhost:3000/api/trips/${tripCode}`;
    return this.http.get<Trip>(url);
  }

  public addTrip(trip: Trip): Observable<Trip> {
    let url = 'http://localhost:3000/api/trips';
    return this.http.post<Trip>(url, trip);
  }

  public updateTrip(trip: Trip): Observable<Trip> {
    let url = `http://localhost:3000/api/trips/${trip.code}`;
    return this.http.put<Trip>(url, trip);
  }

  public deleteTrip(tripCode: string): Observable<Trip> {
    let url = `http://localhost:3000/api/trips/${tripCode}`;
    return this.http.delete<Trip>(url);
  }

  // Call to our /users/login endpoint, returns JWT
  login(user: User, passwd: string): Observable<AuthResponse> {
    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };
    return this.http.post<AuthResponse>(`${this.baseUrl}/users/login`, formData);
  }

  // Call to our /users/register endpoint, creates user and returns JWT
  register(user: User, passwd: string): Observable<AuthResponse> {
    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };
    return this.http.post<AuthResponse>(`${this.baseUrl}/users/register`, formData);
  }
}
