import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  public formError: string = '';
  public formSuccess: string = '';
  public isSubmitting: boolean = false;
  submitted = false;

  credentials = {
    email: '',
    password: ''
  }

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) { }

  ngOnInit(): void {
  }

  public onLoginSubmit(): void {
    this.formError = '';
    this.formSuccess = '';
    this.isSubmitting = true;
    
    if (!this.credentials.email || !this.credentials.password) {
      this.formError = 'All fields are required, please try again';
      this.isSubmitting = false;
      return;
    } else {
      this.doLogin();
    }
  }

  private doLogin(): void {
    let newUser = {
      name: '', // Passing empty string for name but keeping in structure for API
      email: this.credentials.email
    } as User;

    // Attempt to login
    this.authenticationService.login(newUser, this.credentials.password);

    // Check if login was successful
    if(this.authenticationService.isLoggedIn()) {
      this.formSuccess = 'Login successful!';
      this.router.navigate(['']);
    } else {
      var timer = setTimeout(() => {
        this.isSubmitting = false;
        if(this.authenticationService.isLoggedIn()) {
          this.formSuccess = 'Login successful!';
          this.router.navigate(['']);
        } else {
          this.formError = 'Login failed. Please check your credentials and try again.';
        }
      }, 3000);
    }
  }
} 