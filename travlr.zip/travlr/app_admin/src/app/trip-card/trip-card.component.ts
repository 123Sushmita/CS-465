import { CommonModule } from '@angular/common';
import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.component.html',
  styleUrl: './trip-card.component.css',
})
export class TripCardComponent implements OnInit {
  @Input() trip!: Trip;
  @Output() tripDeleted = new EventEmitter<void>();
  isDeleting: boolean = false;

  constructor(
    private router: Router,
    private tripDataService: TripDataService,
    private authenticationService: AuthenticationService
  ) {}

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  editTrip(trip: Trip): void {
    localStorage.removeItem('tripCode');
    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['/edit-trip']);
  }

  deleteTrip(trip: Trip): void {
    if (confirm(`Are you sure you want to delete the trip "${trip.name}"?`)) {
      this.isDeleting = true;
      this.tripDataService.deleteTrip(trip.code).subscribe({
        next: (value: any) => {
          console.log('Trip deleted successfully:', value);
          this.isDeleting = false;
          this.tripDeleted.emit();
        },
        error: (error: any) => {
          console.log('Error deleting trip: ' + error);
          this.isDeleting = false;
          alert('Failed to delete trip. Please try again.');
        },
      });
    }
  }

  ngOnInit(): void {
    // Ensure trip data is valid
    if (!this.trip) {
      console.error('Trip data is missing in TripCardComponent');
    }
  }
}
